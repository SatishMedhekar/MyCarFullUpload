﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCarSale.App.Models
{
public class Range
    {
        public int minvalue { get; set; }
        public int maxvalue { get; set; }
    }


    

}
