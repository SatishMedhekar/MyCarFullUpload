﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MyCarsale.Client;


namespace MyCarSale.App.Controllers
{
    public class DealerController : Controller
    {

        MyCarSaleClient client = new MyCarSaleClient();
        // GET: Dealer
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]   
        public ActionResult Login(int id)
        {
            string message="success";
            if (Request.IsAjaxRequest())
            {
                return RedirectToAction("Details", "Dealer");
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }



        public ActionResult Details()
        {
            CarCollection carcollection = new CarCollection();
            var carinfo = new CarInfo();
            carinfo.intKilometer = 1200;
            carcollection = client.GetCarSearchResult(carinfo);
            return View(carcollection);
        }



        [HttpPost]
        public ActionResult DelCar(int id)
        {
            Car car = new Car { ID = id };

            client.DeleteCar(car);
            return RedirectToAction("Details");
        }





        public ActionResult Edit(int id)
        {
            Car carresp = new Car {ID=id  };

            carresp = client.GetSingleCar(carresp);

            var searchCriteria = client.GetFillSearchCriteria();

            CustomCar customcar = new CustomCar();
            customcar.car = carresp;
            customcar.Dropdowncollection = searchCriteria;

            return View(customcar);
        }


        [HttpPost]
        public ActionResult Edit(CustomCar customcar)
        {
            return RedirectToAction("Details");
        }



    }
}