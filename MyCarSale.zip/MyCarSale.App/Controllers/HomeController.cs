﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MyCarsale.Client;



namespace MyCarSale.App.Controllers
{
    public class HomeController : Controller
    {
        
        MyCarSaleClient client = new MyCarSaleClient();
        CarSearchInfo carsearchinfo = new CarSearchInfo();



       [HttpGet]
        public ActionResult Index()
        {
           
            var searchCriteria = client.GetFillSearchCriteria();
            return View(searchCriteria);
        }


        
        
        public ActionResult CarList(CarSearchInfo carsearchinfo )
        {
            var carinfo = new CarInfo();
            carinfo.intKilometer = 1200;
           var carcollection = client.GetCarSearchResult(carinfo);
            TempData["result"] = carcollection;
            //return PartialView (carcollection);
            //return RedirectToAction("Enquiry");

            return RedirectToAction("Index", "Enquiry", new { carcol = carcollection });
        }
    }


        
    }
