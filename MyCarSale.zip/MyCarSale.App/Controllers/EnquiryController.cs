﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MyCarsale.Client;

namespace MyCarSale.App.Controllers
{
    public class EnquiryController : Controller
    {

        MyCarSaleClient client = new MyCarSaleClient();

        public ActionResult Index()
        {

            CarCollection carcollection = (CarCollection)TempData["result"];
            TempData["result"] = carcollection;
            return View(carcollection);
        }


        public ActionResult PostEnquiry()
        {
        
            return PartialView();
        }


        [HttpPost]
        public ActionResult PostEnquiry(Enquiry enquiry)
        {
            client.PostEnquiry(enquiry);
            CarCollection carcollection = (CarCollection)TempData["result"];
            return RedirectToAction("Index");
        }
    }
}